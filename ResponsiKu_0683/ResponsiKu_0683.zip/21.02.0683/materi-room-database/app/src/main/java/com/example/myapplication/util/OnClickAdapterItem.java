package com.example.myapplication.util;

public interface OnClickAdapterItem {
    void clickItem(int id, int postion);
}
