package com.example.myapplication.util;

public interface DialogImageOptionsListener {
    void onCameraClick();

    void onGalleryClick();
}
